// === Pinos do sensor ultrassônico ===
#define TRIG_PIN 3
#define ECHO_PIN 2

// === Pinos de saída ===
#define RELAY_PIN 8
#define BUZZER_PIN 4
#define LED_PIN 7   // Novo pino para o LED

// Distância limite para acionar (em cm)
#define DISTANCIA_ACIONAR 10  

void setup() {
  Serial.begin(9600);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  pinMode(RELAY_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(RELAY_PIN, LOW);   // Relé desligado no início
  digitalWrite(LED_PIN, LOW);     // LED desligado no início
}

void loop() {
  // Medir a distância
  long duracao;
  int distancia;

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  duracao = pulseIn(ECHO_PIN, HIGH);
  distancia = duracao * 0.034 / 2;

  Serial.print("Distancia: ");
  Serial.print(distancia);
  Serial.println(" cm");

  // Se a mão estiver próxima
  if (distancia > 0 && distancia <= DISTANCIA_ACIONAR) {
    digitalWrite(RELAY_PIN, HIGH);  // Liga lâmpada (ou LED no teste)
    digitalWrite(LED_PIN, HIGH);    // Liga LED teste
    tone(BUZZER_PIN, 1000);         // Emite som de 1 kHz
  } else {
    digitalWrite(RELAY_PIN, LOW);   // Desliga lâmpada (ou LED teste)
    digitalWrite(LED_PIN, LOW);     // Desliga LED teste
    noTone(BUZZER_PIN);             // Para o som
  }

  delay(200); // Pequena pausa para evitar leituras instáveis
}